#!/bin/bash
useradd -s /sbin/nologin zabbix
cd /opt/nginx-1.12.2
./configure --with-http_ssl_module
make && make install
[ -f /opt/nginx.conf ] && cp /opt/nginx.conf /usr/local/nginx/conf/nginx.conf
[ `netstart -lnput |grep nginx|wc -l` -gt 0 ] && /usr/local/nginx/sbin/nginx -s reload
cd /opt/zabbix-3.4.4
./configure  --enable-server --enable-proxy --enable-agent --with-mysql=/usr/bin/mysql_config --with-net-snmp --with-libcurl
make && make install
mysql -e "create database zabbix character set utf8;"
mysql -e "grant all on zabbix.* to zabbix@'localhost' identified by 'zabbix';"
cd /opt/zabbix-3.4.4/database/mysql 
mysql -uzabbix -pzabbix zabbix < schema.sql
mysql -uzabbix -pzabbix zabbix < images.sql
mysql -uzabbix -pzabbix zabbix < data.sql
cp -r /opt/zabbix-3.4.4/frontends/php/* /usr/local/nginx/html/
cp /opt/zabbix_server.conf /usr/local/etc/zabbix_server.conf
systemctl restart php-fpm
zabbix_server
