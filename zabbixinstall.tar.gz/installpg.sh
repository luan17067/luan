#!/bin/bash
yum -y install gcc pcre-devel openssl-devel php php-mysql mariadb-devel mariadb-server php-fpm net-snmp-devel curl-devel libevent-devel php-gd php-xml
cd /opt
yum -y install php-bcmath-5.4.16-42.el7.x86_64.rpm
yum -y install php-mbstring-5.4.16-42.el7.x86_64.rpm
systemctl enable --now  mariadb
systemctl enable --now  php-fpm

